<?php
// Start the session
session_start();
?>
<html>
<head>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<h4>Login</h4>

<label>Email</label><br/>
<input type="email" name="email" value=""/><br/>
<label>Password</label><br/>
<input type="password" name="password" value=""/><br/>
<input type="submit" name="submit" value="Submit"/>
</form>
<a href="register.php">Register</a>
</body>
</html>
<?php
include("connect.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	
	$email=$_POST['email'];
	$password=md5($_POST['password']);
	

//$sql = "INSERT INTO user (first_name, last_name, email, password) VALUES ('$fname', '$lname', '$email', '$password')";
//
//if (mysql_query($sql)) {
//  echo "New record created successfully";
//} else {
//  die('Could not insert: ' . mysql_error());
//}
//
	$sql1="Select * from user where email='$email'";
	$res=mysql_query($sql1);

	$row = mysql_num_rows($res);
	//echo $row;
	if($row==1)
	{
		while($result=mysql_fetch_array($res))
		{
			$_SESSION['userid']=$result[0];
			$_SESSION['username']=$result[1];
		}
		

		//echo $result[0];
		//echo "Welcome to SAI";
		header("Location: dashboard.php");
	}
}
?>