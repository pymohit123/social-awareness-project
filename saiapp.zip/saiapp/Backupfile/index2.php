<html>
<head>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
<label>First Name</label><br/>
<input type="text" name="fname" /><br/>
<label>Last Name</label><br/>
<input type="text" name="lastname" value=""/><br/>
<label>Email</label><br/>
<input type="email" name="email" value=""/><br/>
<label>Password</label><br/>
<input type="password" name="password" value=""/><br/>
<input type="submit" name="submit" value="Submit"/>
</form>
</body>
</html>
<?php
include("connect.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$fname=$_POST['fname'];
	$lname=$_POST['lastname'];
	$email=$_POST['email'];
	$password=md5($_POST['password']);
	echo $fname;
	echo $lname;
	echo $email;
	echo $password;

$sql = "INSERT INTO user (first_name, last_name, email, password) VALUES ('$fname', '$lname', '$email', '$password')";

if (mysql_query($sql)) {
  echo "New record created successfully";
} else {
  die('Could not insert: ' . mysql_error());
}

$sql1="Select * from user";
$res=mysql_query($sql1);
echo $res;
$row = mysql_num_rows($res);
echo $row;
}
?>