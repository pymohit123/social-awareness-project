<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<!-- saved from url=(0059)https://preview.colorlib.com/theme/bootstrap/login-form-11/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Login 01</title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style/font-awesome.min.css">
<link rel="stylesheet" href="style/style.css">
</head>
<body>
<section class="ftco-section">
<div class="container">
<div class="row justify-content-center">
<div class="col-md-6 text-center mb-5">
<h2 class="heading-section">Login #01</h2>
</div>
</div>
<div class="row justify-content-center">
<div class="col-md-7 col-lg-5">
<div class="login-wrap p-4 p-md-5">
<div class="icon d-flex align-items-center justify-content-center">
<span class="fa fa-user-o"></span>
</div>
<h3 class="text-center mb-4">Sign In</h3>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" class="login-form" method='post'>
<div class="form-group">
<input type="email" class="form-control rounded-left" placeholder="Username" required="" name="email" >
</div>
<div class="form-group d-flex">
<input type="password" class="form-control rounded-left" placeholder="Password" required="" name="password">
</div>
<div class="form-group">
<button type="submit" class="form-control btn btn-primary rounded submit px-3">Login</button>
</div>
<div class="form-group d-md-flex">
<div class="w-50">
<label class="checkbox-wrap checkbox-primary">Remember Me
<input type="checkbox" checked="">
<span class="checkmark"></span>
</label>
</div>
<div class="w-50 text-md-right">
<a href="https://preview.colorlib.com/theme/bootstrap/login-form-11/#">Forgot Password</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</section>
<script src="style/jquery.min.js"></script>
<script src="style/popper.js+bootstrap.min.js+main.js.pagespeed.jc.XLbJotJFQf.js"></script><script>eval(mod_pagespeed_WElkAsjnxY);</script>
<script>eval(mod_pagespeed_CLCu_pXgaN);</script>
<script>eval(mod_pagespeed_h$EL5JhDnb);</script>
<script defer="" src="style/beacon.min.js" data-cf-beacon="{&quot;rayId&quot;:&quot;69bdc12e6e706a6e&quot;,&quot;token&quot;:&quot;cd0b4b3a733644fc843ef0b185f98241&quot;,&quot;version&quot;:&quot;2021.9.0&quot;,&quot;si&quot;:100}"></script>


</body></html>

<?php
include("connect.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	
	$email=$_POST['email'];
	$password=md5($_POST['password']);
	

//$sql = "INSERT INTO user (first_name, last_name, email, password) VALUES ('$fname', '$lname', '$email', '$password')";
//
//if (mysql_query($sql)) {
//  echo "New record created successfully";
//} else {
//  die('Could not insert: ' . mysql_error());
//}
//
	$sql1="Select * from user where email='$email'";
	$res=mysql_query($sql1);

	$row = mysql_num_rows($res);
	//echo $row;
	if($row==1)
	{
		while($result=mysql_fetch_array($res))
		{
			$_SESSION['userid']=$result[0];
			$_SESSION['username']=$result[1];
		}
		

		//echo $result[0];
		//echo "Welcome to SAI";
		header("Location: dashboard.php");
	}
}
?>