<?php
// Start the session
session_start();
?>
<html>
<head>
	
</head>
<body>
	<h4>Post Advertisement for Your Business</h4>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
		<label>Title</label>
		<input type="text" name="ad_title"/>
		<label>Description</label>
		<textarea name="ad_description" rows="10" cols="20"></textarea>
		<label>Page Link</label>
		<input type="text" name="ad_link"/>
		<label>Select image to upload:</label>
  		<input type="file" name="fileToUpload" id="fileToUpload">
		<input type="Submit" name="Upload advertisement"/>
	
	</form>
	<a href="logout.php">Logout</a>
</body>
</html>
<?php
//echo $_SESSION['username'];
$_SESSION['userid'];
include("connect.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$ad_title=$_POST['ad_title'];
	$ad_des=$_POST['ad_description'];
	$ad_link=$_POST['ad_link'];
	$sql="INSERT INTO `Advertisement` (`Ad_title`, `Ad_details`, `Ad_link`) VALUES ('$ad_title', '$ad_des', '$ad_link')";
	if(mysql_query($sql))
	{
		header('location: dashboard.php');
	}
	else
	{
		die('Could not insert: ' . mysql_error());
	}
}
?>